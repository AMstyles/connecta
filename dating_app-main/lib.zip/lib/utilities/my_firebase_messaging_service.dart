import 'dart:async';
import 'package:firebase_messaging/firebase_messaging.dart';

Future<void> myBackgroundMessageHandler(RemoteMessage message) async {
  print('Handling a background message: ${message.messageId}');
  // Handle your background message here
}
